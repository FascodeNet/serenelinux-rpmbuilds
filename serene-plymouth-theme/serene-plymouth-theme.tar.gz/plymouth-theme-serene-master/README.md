# plymouth-theme-serene
Plymouth theme for Serene.

# installation
Run install.sh as superuser.

Example:

`sudo ./install.sh serene-logo serene-mso`
